import networkx as nx
import matplotlib.pyplot as plt


# Load the edge list from the dataset
with open("facebook_networkdata.txt", "r") as file:
    edges = [line.strip().split() for line in file.readlines()[250:500]]  # Consider only the first 150 edges


# Create the graph
fb_graph = nx.Graph()
fb_graph.add_edges_from(edges)


# Visualize the graph
plt.figure(figsize=(10, 6))
nx.draw(fb_graph, with_labels=False, node_color='skyblue', node_size=100, edge_color='gray')
plt.title("Facebook Friend Network (First 150)")
plt.show()


# Degree of each node
degree = dict(fb_graph.degree())
print("Degree of each node:", degree)


# Degree centrality
degree_centrality = nx.degree_centrality(fb_graph)
print("Degree centrality:", sorted(degree_centrality.items(), key=lambda x: x[1], reverse=True)[:5])


# Betweenness centrality
betweenness_centrality = nx.betweenness_centrality(fb_graph, normalized=True, endpoints=True)
print("Betweenness centrality:", sorted(betweenness_centrality.items(), key=lambda x: x[1], reverse=True)[:5])


# Closeness centrality
closeness_centrality = nx.closeness_centrality(fb_graph)
print("Closeness centrality:", sorted(closeness_centrality.items(), key=lambda x: x[1], reverse=True)[:5])


# Eigenvector centrality
eigenvector_centrality = nx.eigenvector_centrality(fb_graph)
print("Eigenvector centrality:", sorted(eigenvector_centrality.items(), key=lambda x: x[1], reverse=True)[:5])


# Bridges
bridges = list(nx.bridges(fb_graph))
print("Number of bridges:", len(bridges))


# Visualize the graph with bridges highlighted
plt.figure(figsize=(10, 6))
pos = nx.spring_layout(fb_graph)
nx.draw(fb_graph, pos, with_labels=False, node_color='skyblue', node_size=100, edge_color='gray')
nx.draw_networkx_edges(fb_graph, pos, edgelist=bridges, edge_color='red', width=2)
plt.title("Facebook Friend Network (First 150) with Bridges Highlighted")
plt.show()
