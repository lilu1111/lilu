import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


# Load the dataset
df = pd.read_csv("amazonsentiments.csv")


# Display the first few rows of the dataframe
print(df.head())


# 1. Shape
print("Shape of the dataframe:")
print(df.shape)


# 2. Info
print("\nInfo about the dataframe:")
print(df.info())


# 3. Describe
print("\nDescriptive statistics:")
print(df.describe())


# 4. Null Values
print("\nNumber of null values in each column:")
print(df.isnull().sum())


# 5. Unique Values
print("\nNumber of unique values in each column:")
print(df.nunique())


# Visualization functions
# 1. Histogram
column_name = "ratingScore"
plt.hist(df[column_name], bins=10, color='skyblue', edgecolor='black')
plt.title(f'Histogram of {column_name}')
plt.xlabel(column_name)
plt.ylabel('Frequency')
plt.show()


# 2. Boxplot
column_name = "Sentiment Scores"
sns.boxplot(x=df[column_name])
plt.title(f'Box Plot of {column_name}')
plt.show()


# 3. Scatter Plot
x_column = "ratingScore"
y_column = "Sentiment Scores"
plt.scatter(df[x_column], df[y_column], alpha=0.5)
plt.title(f'Scatter Plot: {x_column} vs {y_column}')
plt.xlabel(x_column)
plt.ylabel(y_column)
plt.show()


# 4. Line plot
sorted_data = df.sort_values(by=y_column)
plt.plot(sorted_data[y_column], sorted_data[x_column], marker='o')
plt.title(f'Line Plot: {y_column} over {x_column} (Sorted)')
plt.xlabel(x_column)
plt.ylabel(y_column)
plt.show()


# 5. Bar plot
# Create bins for sentiment based on rating score
# Create bins for sentiment based on rating score
df['Sentiment'] = pd.qcut(df['ratingScore'], q=[0, 0.25, 0.5, 0.75, 1.0], labels=['Low Rating', 'Medium Rating', 'High Rating'], duplicates='drop')


# Plot the bar plot
y_column = "Sentiment"
sns.barplot(x=y_column, y=x_column, data=df)
plt.title(f'Bar Plot: {x_column} vs {y_column}')
plt.show()
