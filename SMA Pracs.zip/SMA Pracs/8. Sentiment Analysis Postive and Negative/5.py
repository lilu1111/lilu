import pandas as pd
import matplotlib.pyplot as plt
from textblob import TextBlob


# Read the CSV file
df = pd.read_csv('amazonsentiments.csv')  # Replace 'your_file.csv' with the path to your CSV file


# Function to perform sentiment analysis
def analyze_sentiment(text):
    if isinstance(text, str):
        sentiment_score = TextBlob(text).sentiment.polarity
        if sentiment_score > 0:
            return 'Positive'
        elif sentiment_score < 0:
            return 'Negative'
        else:
            return 'Neutral'
    else:
        return 'Neutral'


# Add a new column for sentiment analysis result
df['Sentiment'] = df['reviewDescription'].apply(analyze_sentiment)


# Count the number of positive and negative reviews
sentiment_counts = df['Sentiment'].value_counts()


# Plotting sentiment distribution
plt.figure(figsize=(5,5))
sentiment_counts.plot(kind='bar', color=['green', 'blue','red'])
plt.title('Sentiment Distribution')
plt.xlabel('Sentiment')
plt.ylabel('Count')
plt.xticks(rotation=0)
plt.show()


# Negative Tweets Analysis
negative_tweets = df[df['Sentiment'] == 'Negative']
print("Negative Tweets:")
print(negative_tweets['reviewDescription'].head(5))


# Positive Tweets Analysis
positive_tweets = df[df['Sentiment'] == 'Positive']
print("\nPositive Tweets:")
print(positive_tweets['reviewDescription'].head(5))


# Convert 'date' column to datetime format
df['date'] = pd.to_datetime(df['date'])


# Group by date and sentiment, then count the occurrences
sentiment_over_time = df.groupby([df['date'].dt.date, 'Sentiment']).size().unstack(fill_value=0)


# Plotting sentiment over time
sentiment_over_time.plot(kind='area', stacked=True, figsize=(10, 5))
plt.title('Sentiment Over Time')
plt.xlabel('Date')
plt.ylabel('Count')
plt.legend(title='Sentiment')
plt.show()

